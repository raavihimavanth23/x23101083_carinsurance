<ul>
<li>This library contains files to validate car insurance policies, claims, damages, user cars, etc.</li>
<li>This library provided function to get the policy sum_assurance of a car based on its year of manufacturing and it's previous damages.</li>
<li>It also provided a document_helper function to upload documents to aws s3.</li>
<li>Provides date_utils to play with dates</li>
</ul>
